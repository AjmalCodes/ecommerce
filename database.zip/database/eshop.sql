-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 21, 2024 at 07:56 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `eshop`
--

-- --------------------------------------------------------

--
-- Table structure for table `carts`
--

CREATE TABLE `carts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL,
  `prod_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `carts`
--

INSERT INTO `carts` (`id`, `user_id`, `prod_id`, `created_at`, `updated_at`) VALUES
(14, 1, 2, '2024-07-21 20:04:22', '2024-07-21 20:04:22'),
(15, 1, 6, '2024-07-21 23:00:44', '2024-07-21 23:00:44');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL,
  `slug` varchar(191) NOT NULL,
  `status` varchar(191) NOT NULL DEFAULT '0',
  `popular` varchar(191) NOT NULL DEFAULT '0',
  `meta_title` varchar(191) NOT NULL,
  `meta_keywords` varchar(191) NOT NULL,
  `description` varchar(191) NOT NULL,
  `image` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `slug`, `status`, `popular`, `meta_title`, `meta_keywords`, `description`, `image`, `created_at`, `updated_at`) VALUES
(1, 'Clothes', 'clothes', '0', '1', 'clothe', 'clothes', 'all clothes are available here in this category', '1717390785.png', '2024-06-03 10:59:45', '2024-06-03 11:00:48'),
(2, 'ring', 'ring', '1', '0', 'ring, rings, turkish rings', 'ring, rings, turkish rings', 'ring, rings, turkish rings', '1721136050.jpeg', '2024-07-16 19:20:50', '2024-07-16 19:20:50'),
(3, 'Turkish Rings', 'turkish-rings', '1', '1', 'turkish-rings', 'turkish-rings', 'turkish-rings turkish-rings', '1721416827.jpeg', '2024-07-20 01:20:27', '2024-07-20 01:20:27');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(191) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_reset_tokens_table', 1),
(3, '2014_10_12_100000_create_password_resets_table', 1),
(4, '2019_08_19_000000_create_failed_jobs_table', 1),
(5, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(6, '2023_04_25_122143_create_categories_table', 1),
(7, '2023_04_25_155544_create_products_table', 1),
(8, '2023_05_06_152709_create_carts_table', 1),
(9, '2023_05_07_080310_create_orders_table', 1),
(10, '2023_05_07_080847_create_order_items_table', 1),
(11, '2024_07_20_165516_add_columns_to_users_table', 2),
(12, '2024_07_20_175856_modify_description_in_products_table', 3);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` varchar(191) NOT NULL,
  `fname` varchar(191) NOT NULL,
  `lname` varchar(191) NOT NULL,
  `email` varchar(191) NOT NULL,
  `phone` varchar(191) NOT NULL,
  `address` varchar(191) NOT NULL,
  `city` varchar(191) NOT NULL,
  `country` varchar(191) NOT NULL,
  `state` varchar(191) NOT NULL,
  `pincode` varchar(191) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 0,
  `message` varchar(191) DEFAULT NULL,
  `tracking_no` varchar(191) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `fname`, `lname`, `email`, `phone`, `address`, `city`, `country`, `state`, `pincode`, `status`, `message`, `tracking_no`, `created_at`, `updated_at`) VALUES
(1, '1', 'Brennan Valencia', 'Jonah David', 'dyryju@mailinator.com', '+1 (664) 619-2912', 'Aspernatur error seq', 'Debitis incididunt e', 'Ducimus quos dolore', 'Recusandae Est rer', 'Eum nihil deserunt m', 0, NULL, '3735', '2024-07-20 22:47:56', '2024-07-20 22:47:56'),
(2, '1', 'Brennan Valencia', 'Jonah David', 'dyryju@mailinator.com', '+1 (664) 619-2912', 'Aspernatur error seq', 'Debitis incididunt e', 'Ducimus quos dolore', 'Recusandae Est rer', 'Eum nihil deserunt m', 0, NULL, '6756', '2024-07-20 22:48:09', '2024-07-20 22:48:09'),
(3, '1', 'Brennan Valencia', 'Jonah David', 'dyryju@mailinator.com', '+1 (664) 619-2912', 'Aspernatur error seq', 'Debitis incididunt e', 'Ducimus quos dolore', 'Recusandae Est rer', 'Eum nihil deserunt m', 0, NULL, '9169', '2024-07-20 22:50:27', '2024-07-20 22:50:27'),
(4, '1', 'Elliott Oneil', 'Cathleen Contreras', 'cimat@mailinator.com', '+1 (516) 672-9117', 'Aute ut impedit ali', 'Molestias expedita n', 'Cum eaque aliquip ma', 'Ipsum consectetur a', 'Amet esse in liber', 0, NULL, '3164', '2024-07-20 22:56:40', '2024-07-20 22:56:40'),
(5, '1', 'Elliott Oneil', 'Cathleen Contreras', 'moon@gmail.com', '+1 (516) 672-9117', 'Aute ut impedit ali', 'Molestias expedita n', 'Cum eaque aliquip ma', 'Ipsum consectetur a', 'Amet esse in liber', 0, NULL, '5035', '2024-07-21 19:59:04', '2024-07-21 19:59:04');

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

CREATE TABLE `order_items` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `order_id` varchar(191) NOT NULL,
  `prod_id` varchar(191) NOT NULL,
  `price` varchar(191) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `order_items`
--

INSERT INTO `order_items` (`id`, `order_id`, `prod_id`, `price`, `created_at`, `updated_at`) VALUES
(1, '1', '1', '10', '2024-07-20 22:47:56', '2024-07-20 22:47:56'),
(2, '1', '2', 'Dylan Moore', '2024-07-20 22:47:56', '2024-07-20 22:47:56'),
(3, '1', '3', 'Shana Bowen', '2024-07-20 22:47:56', '2024-07-20 22:47:56'),
(4, '2', '1', '10', '2024-07-20 22:48:09', '2024-07-20 22:48:09'),
(5, '2', '2', 'Dylan Moore', '2024-07-20 22:48:09', '2024-07-20 22:48:09'),
(6, '2', '3', 'Shana Bowen', '2024-07-20 22:48:09', '2024-07-20 22:48:09'),
(7, '3', '1', '10', '2024-07-20 22:50:27', '2024-07-20 22:50:27'),
(8, '3', '2', 'Dylan Moore', '2024-07-20 22:50:27', '2024-07-20 22:50:27'),
(9, '3', '3', 'Shana Bowen', '2024-07-20 22:50:27', '2024-07-20 22:50:27'),
(10, '4', '1', '10', '2024-07-20 22:56:40', '2024-07-20 22:56:40'),
(11, '4', '2', 'Dylan Moore', '2024-07-20 22:56:40', '2024-07-20 22:56:40'),
(12, '4', '3', 'Shana Bowen', '2024-07-20 22:56:40', '2024-07-20 22:56:40'),
(13, '5', '4', '14', '2024-07-21 19:59:04', '2024-07-21 19:59:04'),
(14, '5', '6', '19', '2024-07-21 19:59:04', '2024-07-21 19:59:04'),
(15, '5', '3', '13', '2024-07-21 19:59:04', '2024-07-21 19:59:04'),
(16, '5', '7', '10', '2024-07-21 19:59:04', '2024-07-21 19:59:04');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) NOT NULL,
  `token` varchar(191) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `password_reset_tokens`
--

CREATE TABLE `password_reset_tokens` (
  `email` varchar(191) NOT NULL,
  `token` varchar(191) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(191) NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `cate_id` bigint(20) NOT NULL,
  `name` varchar(191) NOT NULL,
  `slug` varchar(191) NOT NULL,
  `selling_price` varchar(191) NOT NULL,
  `original_price` varchar(191) NOT NULL,
  `qty` varchar(191) NOT NULL,
  `status` varchar(191) NOT NULL DEFAULT '0',
  `popular` varchar(191) NOT NULL DEFAULT '0',
  `meta_title` varchar(191) NOT NULL,
  `meta_keywords` varchar(191) NOT NULL,
  `description` longtext NOT NULL,
  `image` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `cate_id`, `name`, `slug`, `selling_price`, `original_price`, `qty`, `status`, `popular`, `meta_title`, `meta_keywords`, `description`, `image`, `created_at`, `updated_at`) VALUES
(1, 1, 'Shirt', 'shirts', '10', '12', '12', '0', '1', 'shirt', 'shirts', 'branded shirtbranded shirt Modify your form to handle the submission of selected items. The form should have a POST method pointing to the checkout URL, and it should include a CSRF token for security.Modify your form to handle the submission of selected items. The form should have a POST method pointing to the checkout URL, and it should include a CSRF token for security.Modify your form to handle the submission of selected items. The form should have a POST method pointing to the checkout URL, and it should include a CSRF token for security.Modify your form to handle the submission of selected items. The form should have a POST method pointing to the checkout URL, and it should include a CSRF token for security.Modify your form to handle the submission of selected items. The form should have a POST method pointing to the checkout URL, and it should include a CSRF token for security.Modify your form to handle the submission of selected items. The form should have a POST method pointing to the checkout URL, and it should include a CSRF token for security.Modify your form to handle the submission of selected items. The form should have a POST method pointing to the checkout URL, and it should include a CSRF token for security.Modify your form to handle the submission of selected items. The form should have a POST method pointing to the checkout URL, and it should include a CSRF token for security.Modify your form to handle the submission of selected items. The form should have a POST method pointing to the checkout URL, and it should include a CSRF token for security.Modify your form to handle the submission of selected items. The form should have a POST method pointing to the checkout URL, and it should include a CSRF token for security.', '1717390914.png', '2024-06-03 11:01:54', '2024-07-21 00:00:15'),
(2, 1, 'test', 'test', '12', '12', 'Bertha Lancaster', '0', '1', 'Bert Mckay', 'Odette Hays', 'Eu sit qui ut et vol', '1721417543.png', '2024-07-20 01:32:04', '2024-07-20 23:53:53'),
(3, 2, 'Eagan Mullins', 'Maryam Levine', '13', '12', 'Brielle Baker', '0', '1', 'Cecilia Knox', 'Lani Oliver', 'Sapiente exercitatio', '1721468286.png', '2024-07-20 15:38:06', '2024-07-20 23:51:14'),
(4, 3, 'Jayme Cochran', 'Mikayla Marshall', '14', '12', 'Martin Acevedo', '0', '1', 'David Shelton', 'Leilani Nunez', 'Aut facere quam veni', '1721468315.png', '2024-07-20 15:38:19', '2024-07-20 23:51:28'),
(5, 1, 'Lani Cleveland', 'Medge Witt', '15', '11', 'Drake Berg', '1', '1', 'Craig Shannon', 'Ralph Sloan', 'Voluptates vel eaque', '1721468345.png', '2024-07-20 15:38:47', '2024-07-20 23:51:55'),
(6, 3, 'Mohammad Moss', 'Denton Campbell', '19', '10', 'Melissa Perry', '0', '1', 'Jonah Jackson', 'Anika Bennett', 'Velit voluptas aut r', '1721468410.png', '2024-07-20 15:40:10', '2024-07-20 23:52:08'),
(7, 2, 'Ivana Heath', 'Yetta Wall', '10', '8', 'Brennan Savage', '0', '1', 'Lila Gibbs', 'Austin Hoover', 'Debitis et quos obca', '1721468426.png', '2024-07-20 15:40:26', '2024-07-20 23:52:24');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL,
  `email` varchar(191) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) NOT NULL,
  `role_as` tinyint(4) NOT NULL DEFAULT 0,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `lname` varchar(191) DEFAULT NULL,
  `address` varchar(191) DEFAULT NULL,
  `phone` varchar(191) DEFAULT NULL,
  `country` varchar(191) DEFAULT NULL,
  `city` varchar(191) DEFAULT NULL,
  `state` varchar(191) DEFAULT NULL,
  `pincode` varchar(191) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `role_as`, `remember_token`, `created_at`, `updated_at`, `lname`, `address`, `phone`, `country`, `city`, `state`, `pincode`) VALUES
(1, 'Elliott Oneil', 'moon@gmail.com', NULL, '$2y$10$bsVcUpXPD3H4Rq5.NnneOe.pqJjyEL1y2Ut.3ai2GnAw4.1Vj3V0G', 1, NULL, '2024-06-03 10:58:09', '2024-07-20 22:56:40', 'Cathleen Contreras', 'Aute ut impedit ali', '+1 (516) 672-9117', 'Cum eaque aliquip ma', 'Molestias expedita n', 'Ipsum consectetur a', 'Amet esse in liber'),
(2, 'Jayme Everett', 'napiky@mailinator.com', NULL, '$2y$10$f1OsNT6cL4IlnGXnp1iiwemyQOCL0Q2G45To7hyh6r60bw1m12azy', 0, NULL, '2024-07-21 23:38:34', '2024-07-21 23:38:34', NULL, NULL, NULL, NULL, NULL, NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `carts`
--
ALTER TABLE `carts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `carts`
--
ALTER TABLE `carts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `order_items`
--
ALTER TABLE `order_items`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
